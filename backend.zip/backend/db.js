const { Pool } = require("pg");

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "goal_tracker",
  password: "Nidhi@1807",
  port: 5432,
});

module.exports = pool;