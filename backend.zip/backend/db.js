const { Pool } = require("pg");

const pool = new Pool({
  connectionString:
    "postgresql://postgres:Nidhi%4018072005@db.lkuhgjpnwdxpfoesqsob.supabase.co:5432/postgres",
  ssl: {
    rejectUnauthorized: false,
  },
});

module.exports = pool;